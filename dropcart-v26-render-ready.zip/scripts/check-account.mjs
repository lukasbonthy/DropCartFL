import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFile, readdir, mkdir } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";

const require = createRequire(import.meta.url);
const { build } = createRequire(require.resolve("drizzle-kit"))("esbuild");
await mkdir(".sites-runtime", { recursive: true });
await build({ entryPoints: ["lib/account-data.ts"], bundle: true, platform: "node", format: "esm", outfile: ".sites-runtime/account-test-bundle.mjs" });
const { readAccountHistory, formatAccountDate, formatAccountTime, statusPresentation } = await import("../.sites-runtime/account-test-bundle.mjs");
const sql = new DatabaseSync(":memory:");
for (const file of (await readdir("drizzle")).filter(file => file.endsWith(".sql")).sort()) sql.exec(await readFile(`drizzle/${file}`, "utf8"));
const db = {
  prepare(query) {
    return { bind(...values) { return { query, values }; } };
  },
  async batch(statements) {
    return statements.map(({ query, values }) => ({ success: true, results: sql.prepare(query).all(...values) }));
  },
};
const insert = sql.prepare(`INSERT INTO bookings (id, reference, request_digest, created_at, arrival_at, eta_minutes, status, customer_name, phone, address, city, state, zip, grocery_load, stairs, notes, contact_consent, source_key, user_id)
  VALUES (?, ?, 'digest', ?, ?, 30, ?, 'Test customer', '3525550100', '120 Example Lane', 'Inverness', 'FL', '34450', 'medium', 0, '', 1, 'test', ?)`);
for (let i = 0; i < 25; i++) insert.run(`a-${i}`, `DC-A${i}`, 1000 + i, 2000 + i, i < 10 ? "pending" : "completed", "owner-a");
insert.run("b-1", "DC-PRIVATE-B", 999999, 1000999, "confirmed", "owner-b");
insert.run("guest-1", "DC-GUEST", 999998, 1000998, "pending", null);
const result = await readAccountHistory(db, "owner-a");
assert.equal(result.counts.total, 25);
assert.equal(result.counts.active, 10);
assert.equal(result.counts.completed, 15);
assert.equal(result.bookings.length, 20);
assert.equal(result.bookings[0].reference, "DC-A24");
assert.equal(result.bookings.some(row => row.reference === "DC-PRIVATE-B" || row.reference === "DC-GUEST"), false);
const empty = await readAccountHistory(db, "new-owner");
assert.deepEqual({ ...empty.counts }, { total: 0, active: 0, completed: 0 });
assert.equal(empty.bookings.length, 0);
await assert.rejects(() => readAccountHistory(db, ""));
await assert.rejects(() => readAccountHistory({ ...db, async batch() { return [{ success: false }]; } }, "owner-a"));
assert.equal(formatAccountDate(Date.parse("2026-09-15T01:00:00Z")), "Sep 14, 2026");
assert.match(formatAccountTime(Date.parse("2026-09-15T01:00:00Z")), /9:00 PM/);
assert.match(formatAccountTime(Date.parse("2026-01-15T01:00:00Z")), /8:00 PM/);
assert.equal(statusPresentation("pending").label, "Awaiting confirmation");
assert.equal(statusPresentation("confirmed").label, "Confirmed");
assert.equal(statusPresentation("completed").label, "Completed");
assert.equal(statusPresentation("cancelled").label, "Cancelled");
assert.equal(statusPresentation("unexpected").tone, "unknown");
assert.notEqual(statusPresentation("unexpected").label, "Awaiting confirmation");
sql.close();
console.log("PASS: account ownership, guest isolation, full-history totals, ordering, empty/error states, Florida time zone, and honest status labels.");
