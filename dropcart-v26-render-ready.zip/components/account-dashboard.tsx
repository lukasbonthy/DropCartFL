"use client";

import { useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarClock,
  Check,
  CheckCircle2,
  CircleHelp,
  Clock3,
  Copy,
  House,
  ListChecks,
  LogOut,
  MapPin,
  MessageSquareText,
  ShieldCheck,
  ShoppingBag,
  Star,
  WalletCards,
} from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { AnimatedWords } from "@/components/animated-text";
import { DropcartWordmark } from "@/components/dropcart-wordmark";
import { accountFirstName, accountInitials, accountLoadLabel, formatAccountDate, formatAccountTime, statusPresentation, type AccountHistory, type BookingSummary } from "@/lib/account-data";
import { getDashboardReveal, getDashboardStagger } from "@/lib/dashboard-motion";
import { formatPrice, getUnloadPrice, type GroceryLoad } from "@/lib/pricing";

type Props = {
  user: { displayName: string; email: string };
  history: AccountHistory | null;
  signOutHref: string;
};

function Status({ status }: { status: string }) {
  const presentation = statusPresentation(status);
  return <span className={`account-status ${presentation.tone}`}>{presentation.label}</span>;
}

function bookingPrice(booking: BookingSummary) {
  const load = booking.grocery_load as GroceryLoad;
  return load === "small" || load === "medium" || load === "large"
    ? formatPrice(getUnloadPrice(load, Boolean(booking.stairs)))
    : null;
}

function LatestRequest({ booking }: { booking: BookingSummary }) {
  const status = statusPresentation(booking.status);
  const price = bookingPrice(booking);
  const [copied, setCopied] = useState(false);

  async function copyLatestAddress() {
    const fullAddress = `${booking.address}, ${booking.city}, ${booking.state} ${booking.zip}`;
    try {
      await navigator.clipboard.writeText(fullAddress);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  const title = status.stage === 0
    ? "We’ve got your request."
    : status.stage === 1
      ? "Your unload is lined up."
      : status.stage === 2
        ? "The heavy part is done."
        : "Your latest unload.";

  return <article className="dashboard-feature dashboard-spotlight" aria-labelledby="latest-request-title">
    <span className="dashboard-spotlight-orb orb-one" aria-hidden="true"/>
    <span className="dashboard-spotlight-orb orb-two" aria-hidden="true"/>
    <div className="dashboard-feature-top">
      <div><span className="dashboard-eyebrow">Current unload</span><span className="dashboard-reference">{booking.reference}</span></div>
      <Status status={booking.status}/>
    </div>

    <div className="dashboard-spotlight-layout">
      <div className="dashboard-spotlight-copy">
        <h2 id="latest-request-title"><AnimatedWords lines={[title]} trigger="inherit" delay={0.03} /></h2>
        <div className="dashboard-feature-address"><MapPin size={18} aria-hidden="true"/><span>{booking.address}<small>{booking.city}, {booking.state} {booking.zip}</small></span></div>
        <p className="dashboard-feature-note">{status.description}</p>
        <div className="dashboard-route-visual" aria-label="Dropcart unload route from trunk to kitchen">
          <span><ShoppingBag size={15} aria-hidden="true"/><small>From trunk</small></span>
          <i aria-hidden="true"><b/></i>
          <span><House size={15} aria-hidden="true"/><small>To kitchen</small></span>
        </div>
      </div>

      <div className="dashboard-spotlight-meta" aria-label="Latest request details">
        <span><CalendarClock size={16} aria-hidden="true"/><small>Arrival</small><b>{formatAccountTime(booking.arrival_at)}</b><em>{formatAccountDate(booking.arrival_at)}</em></span>
        <span><ShoppingBag size={16} aria-hidden="true"/><small>Load</small><b>{accountLoadLabel(booking.grocery_load)}</b><em>{booking.stairs ? "Stairs included" : "No stairs"}</em></span>
        {price && <span><WalletCards size={16} aria-hidden="true"/><small>Total</small><b>{price}</b><em>No payment now</em></span>}
      </div>
    </div>

    {status.stage >= 0 && <ol className="request-milestones" aria-label="Request progress">
      {["Requested", "Confirmed", "Completed"].map((label, index) => <li key={label} className={index <= status.stage ? "reached" : ""} aria-current={index === status.stage ? "step" : undefined}>
        <span className="milestone-dot">{index < status.stage ? <Check size={12} aria-hidden="true"/> : index + 1}</span><span>{label}</span>
      </li>)}
    </ol>}

    <div className="dashboard-feature-actions" aria-label="Current unload actions">
      <button type="button" onClick={copyLatestAddress} className={copied ? "copied" : ""}>
        {copied ? <Check size={15} aria-hidden="true"/> : <Copy size={15} aria-hidden="true"/>}
        {copied ? "Address copied" : "Copy address"}
      </button>
      <a href="/#book"><ShoppingBag size={15} aria-hidden="true"/> Book another</a>
    </div>

    <div className="dashboard-feature-bottom"><span>From your trunk to your kitchen.</span><a href={`#request-${booking.reference}`}>View details <ArrowRight size={16} aria-hidden="true"/></a></div>
  </article>;
}

function ReviewPrompt({ booking }: { booking: BookingSummary }) {
  const [rating, setRating] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  function saveRating(value: number) {
    setRating(value);
    try { window.localStorage.setItem(`dropcart-rating-${booking.reference}`, String(value)); } catch { /* local storage is optional */ }
  }

  return <section className="dashboard-review-prompt" aria-labelledby="review-prompt-title">
    <span className="dashboard-review-icon"><MessageSquareText size={20} aria-hidden="true"/></span>
    <div className="dashboard-review-copy">
      <p className="dashboard-eyebrow">Your last unload</p>
      <h2 id="review-prompt-title"><AnimatedWords lines={["How did we do?"]} trigger="inherit" delay={0.03} /></h2>
      <p>{submitted ? "Thanks — your rating is saved on this device for now." : "A quick rating helps shape the Dropcart experience."}</p>
    </div>
    <div className="dashboard-review-controls" aria-label="Rate this unload from 1 to 5 stars">
      {[1, 2, 3, 4, 5].map((value) => <button key={value} type="button" className={value <= rating ? "selected" : ""} aria-label={`${value} star${value === 1 ? "" : "s"}`} aria-pressed={value === rating} onClick={() => { saveRating(value); setSubmitted(true); }}><Star size={19} fill={value <= rating ? "currentColor" : "none"} aria-hidden="true"/></button>)}
    </div>
  </section>;
}

function HistoryRow({ booking }: { booking: BookingSummary }) {
  const price = bookingPrice(booking);
  return <article className="history-row" id={`request-${booking.reference}`}>
    <div className="history-row-heading">
      <span className="history-row-icon"><ShoppingBag size={18} aria-hidden="true"/></span>
      <div className="history-row-title"><h3>{accountLoadLabel(booking.grocery_load)}{booking.stairs ? " · Stairs" : ""}</h3><span>{formatAccountDate(booking.created_at)} <span aria-hidden="true">·</span> <span className="request-reference">{booking.reference}</span></span></div>
      <Status status={booking.status}/>
    </div>
    <div className="history-row-inline">
      <span><MapPin size={14} aria-hidden="true"/>{booking.address}, {booking.city}</span>
      <span><Clock3 size={14} aria-hidden="true"/>{formatAccountTime(booking.arrival_at)}</span>
      {price && <span><WalletCards size={14} aria-hidden="true"/>{price}</span>}
    </div>
    <div className="history-row-footer">
      <span>{booking.state} {booking.zip}</span>
      <a href="/#book">Book again <ArrowUpRight size={14} aria-hidden="true"/></a>
    </div>
  </article>;
}

function QuickActions() {
  const actions = [
    { href: "/#book", icon: ShoppingBag, label: "Book another unload", text: "New unload" },
    { href: "#history", icon: ListChecks, label: "History", text: "Past requests" },
    { href: "/#pricing", icon: WalletCards, label: "Pricing", text: "Load rates" },
    { href: "/#questions", icon: CircleHelp, label: "Help", text: "Quick answers" },
  ];

  return <section className="dashboard-commandbar dashboard-quick-actions" aria-labelledby="quick-actions-title">
    <div className="dashboard-commandbar-title"><p className="dashboard-eyebrow">Quick access</p><h2 id="quick-actions-title"><AnimatedWords lines={["Jump back in."]} trigger="inherit" delay={0.03} /></h2><p>Everything you use most, right here.</p></div>
    <div className="dashboard-commandbar-actions">
      {actions.map(({ href, icon: Icon, label, text }, index) => <a href={href} key={label} className={`dashboard-action-tile ${index === 0 ? "dashboard-action-primary" : ""}`}><span><Icon size={19} aria-hidden="true"/></span><div><strong>{label}</strong><small>{text}</small></div><ArrowUpRight size={15} aria-hidden="true"/></a>)}
    </div>
  </section>;
}

export function AccountDashboard({ user, history, signOutHref }: Props) {
  const reduceMotion = !!useReducedMotion();
  const [historyFilter, setHistoryFilter] = useState<"all" | "active" | "completed">("all");
  const latest = history?.bookings[0];
  const counts = history?.counts;
  const completedRate = counts?.total ? Math.round((counts.completed / counts.total) * 100) : 0;
  const filteredBookings = history?.bookings.filter((booking) => {
    if (historyFilter === "all") return true;
    if (historyFilter === "completed") return booking.status === "completed";
    return booking.status === "pending" || booking.status === "confirmed";
  }) ?? [];
  const reveal = getDashboardReveal(reduceMotion);
  const stagger = getDashboardStagger(reduceMotion);

  return <div className="dashboard-page">
    <a href="#dashboard-content" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:rounded-xl focus:bg-white focus:p-4">Skip to your account</a>
    <header className="topbar shell dashboard-topbar">
      <a href="/" className="brand" aria-label="Dropcart home"><DropcartWordmark /></a>
      <nav aria-label="Account navigation" className="dashboard-nav"><a href="/" className="account-link dashboard-home-link">Back to site</a><a href={signOutHref} target="_top" className="account-link"><LogOut size={16} aria-hidden="true"/> Sign out</a><span className="account-avatar" aria-hidden="true">{accountInitials(user.displayName)}</span></nav>
    </header>

    <motion.main
      id="dashboard-content"
      className="dashboard shell"
      initial={reduceMotion ? false : "hidden"}
      animate="shown"
      variants={{ hidden: {}, shown: { transition: stagger } }}
    >
      <motion.section className="dashboard-command-center" aria-labelledby="dashboard-title" variants={reveal}>
        <span className="dashboard-command-orb command-orb-a" aria-hidden="true" />
        <span className="dashboard-command-orb command-orb-b" aria-hidden="true" />
        <div className="dashboard-command-copy">
          <span className="dashboard-command-status"><i aria-hidden="true" /> Local crew ready <small>Inverness & nearby</small></span>
          <h1 id="dashboard-title"><AnimatedWords lines={[`Hey, ${accountFirstName(user.displayName)}.`]} trigger="inherit" delay={0.02} /></h1>
          <p>Your groceries have a home base now. See what’s moving, jump back into a booking, or check the details without hunting around.</p>
          <div className="dashboard-command-actions">
            <a href="/#book" className="account-primary-action" data-cursor-interactive>Book an unload <ArrowUpRight size={17} aria-hidden="true"/></a>
            <a href="#history" className="dashboard-command-secondary">View history <ArrowRight size={15} aria-hidden="true"/></a>
          </div>
        </div>
        <div className="dashboard-command-side">
          <p className="dashboard-command-side-label">Your Dropcart at a glance</p>
          <div className="dashboard-command-metrics" aria-label="Account summary">
            <span><small>Active</small><strong>{counts?.active ?? 0}</strong><em>right now</em></span>
            <span><small>Completed</small><strong>{counts?.completed ?? 0}</strong><em>{completedRate}% of requests</em></span>
            <span><small>Total</small><strong>{counts?.total ?? 0}</strong><em>all time</em></span>
          </div>
          <div className="dashboard-command-trust"><span><ShieldCheck size={15} aria-hidden="true"/> No payment up front</span><span><CheckCircle2 size={15} aria-hidden="true"/> Team confirmed</span></div>
        </div>
      </motion.section>

      <motion.section className="dashboard-canvas" variants={reveal}>
        <div className="dashboard-workspace">

          {!history ? <section className="dashboard-unavailable" role="status"><span className="dashboard-empty-icon"><Clock3 size={23} aria-hidden="true"/></span><h2>Your requests couldn’t load.</h2><p>Your account is signed in, but your request history is temporarily unavailable.</p><a className="account-primary-action" href="/account">Try again <ArrowRight size={16} aria-hidden="true"/></a></section> : latest ? <LatestRequest booking={latest}/> : <section className="dashboard-feature dashboard-first-unload">
            <span className="dashboard-feature-bag"><ShoppingBag size={27} strokeWidth={1.6} aria-hidden="true"/></span>
            <p className="dashboard-eyebrow">Ready when you are</p><h2>Your first unload<br/>starts here.</h2><p className="dashboard-feature-note">Book before you leave the store. We’ll help get your groceries from trunk to kitchen.</p><a href="/#book" className="account-primary-action">Book your first unload <ArrowUpRight size={17} aria-hidden="true"/></a><span className="dashboard-feature-fineprint">No payment now. Team confirmation required.</span>
          </section>}

          {latest?.status === "completed" && <ReviewPrompt booking={latest}/>}          
          <QuickActions />

          {history && <section id="history" className="dashboard-history" aria-labelledby="history-title">
            <div className="dashboard-section-head">
              <div><p className="dashboard-eyebrow">Recent activity</p><h2 id="history-title"><AnimatedWords lines={["Your unloads"]} trigger="inherit" delay={0.03} /></h2><p>{counts && counts.total > 20 ? `Showing your 20 most recent of ${counts.total}.` : "A clean record of every recent request."}</p></div>
              <div className="dashboard-history-tools">
                <div className="dashboard-history-filters" role="group" aria-label="Filter request history">
                  {[
                    ["all", "All"],
                    ["active", "Active"],
                    ["completed", "Completed"],
                  ].map(([value, label]) => <button key={value} type="button" className={`dashboard-history-filter ${historyFilter === value ? "active" : ""}`} aria-pressed={historyFilter === value} onClick={() => setHistoryFilter(value as "all" | "active" | "completed")}>{label}</button>)}
                </div>
                <span className="history-count" aria-label={`${filteredBookings.length} requests shown`}>{filteredBookings.length}</span>
              </div>
            </div>
            {history.bookings.length === 0 ? <div className="dashboard-history-empty"><span className="dashboard-history-empty-icon"><ShoppingBag size={22} aria-hidden="true"/></span><div><h3>No unloads yet.</h3><p>Your first request will show up here.</p><a href="/#book">Book your first unload <ArrowRight size={14} aria-hidden="true"/></a></div></div> : filteredBookings.length ? <div className="dashboard-history-list">{filteredBookings.map(booking => <HistoryRow key={booking.reference} booking={booking}/>)}</div> : <div className="dashboard-history-empty dashboard-history-filter-empty"><span className="dashboard-history-empty-icon"><ListChecks size={22} aria-hidden="true"/></span><div><h3>No {historyFilter} unloads.</h3><p>Try another filter to see your requests.</p></div></div>}
          </section>}
        </div>

        <motion.aside className="dashboard-activity-rail" aria-label="Account details" variants={reveal}>
          <section className="dashboard-next-step" aria-labelledby="dashboard-next-step-title">
            <div className="dashboard-next-step-top"><span className="dashboard-eyebrow">What’s next</span><span className={`dashboard-next-step-dot ${counts?.active ? "is-live" : ""}`} aria-hidden="true" /></div>
            <h2 id="dashboard-next-step-title">{counts?.active ? "Your unload is moving." : latest ? "Ready for the next run?" : "Make the first one easy."}</h2>
            <p>{counts?.active ? "Your active request stays front and center. We’ll keep the important details together here." : "Book before you leave the store and come home to less carrying."}</p>
            <a href={counts?.active ? "#latest-request-title" : "/#book"}>{counts?.active ? "See current unload" : "Book an unload"}<ArrowRight size={15} aria-hidden="true"/></a>
          </section>

          <section className="dashboard-rail-profile dashboard-profile">
            <div className="dashboard-profile-heading"><div><p className="dashboard-eyebrow">Account</p><h2>{user.displayName}</h2></div><span className="account-avatar dashboard-avatar" aria-hidden="true">{accountInitials(user.displayName)}</span></div>
            <p className="dashboard-email">{user.email}</p>
            <span className="dashboard-auth-label"><CheckCircle2 size={14} aria-hidden="true"/> Signed in securely</span>
            {latest && <div className="dashboard-last-address"><span className="dashboard-meta-label"><MapPin size={15} aria-hidden="true"/> Last address</span><p>{latest.address}<span>{latest.city}, {latest.state} {latest.zip}</span></p></div>}
            <div className="dashboard-rail-service"><span><MapPin size={17} aria-hidden="true"/></span><div><small>Service area</small><strong>Inverness & nearby</strong><p>We confirm each arrival window before it’s final.</p></div></div>
          </section>


          <section className="dashboard-help"><CircleHelp size={20} aria-hidden="true"/><div><h2>Need anything?</h2><p>Pricing, stairs, timing, and common questions are one tap away.</p></div><a href="/#questions" aria-label="Open FAQs"><ArrowUpRight size={16} aria-hidden="true"/></a></section>
        </motion.aside>
      </motion.section>

      <footer className="dashboard-footer"><span>From your car. To your kitchen.</span><a href="/">Back to Dropcart <ArrowUpRight size={14} aria-hidden="true"/></a></footer>
    </motion.main>

    <nav className="dashboard-mobile-dock" aria-label="Dashboard shortcuts">
      <a href="#dashboard-content" className="active"><House size={18} aria-hidden="true"/><span>Overview</span></a>
      <a href="/#book"><ShoppingBag size={18} aria-hidden="true"/><span>Book</span></a>
      <a href="#history"><ListChecks size={18} aria-hidden="true"/><span>History</span></a>
      <a href="/#questions"><CircleHelp size={18} aria-hidden="true"/><span>Help</span></a>
    </nav>
  </div>;
}
