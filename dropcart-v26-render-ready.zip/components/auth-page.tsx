"use client";

import { FormEvent, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Eye,
  EyeOff,
  LockKeyhole,
  Mail,
  MapPin,
  ShieldCheck,
  ShoppingBag,
  UserRound,
} from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { AnimatedWords } from "@/components/animated-text";
import { DropcartWordmark } from "@/components/dropcart-wordmark";
import { MOTION_TIMING, dropcartSpring, getRevealVariants, getStaggerTransition } from "@/lib/motion-system";

type AuthPageProps = {
  mode: "login" | "signup";
  returnTo?: string;
};

type AuthResponse = { ok?: boolean; error?: string; redirectTo?: string };

export function AuthPage({ mode, returnTo = "/account" }: AuthPageProps) {
  const signup = mode === "signup";
  const reduceMotion = !!useReducedMotion();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const stageSequence = {
    hidden: {},
    shown: { transition: getStaggerTransition(reduceMotion, 0.03, 0.085) },
  };
  const reveal = getRevealVariants(reduceMotion, 14);
  const quietReveal = getRevealVariants(reduceMotion, 9);

  const passwordProgress = useMemo(() => {
    if (!password) return 0;
    let score = Math.min(password.length / 12, 1) * 55;
    if (/[A-Za-z]/.test(password) && /\d/.test(password)) score += 20;
    if (/[^A-Za-z0-9]/.test(password)) score += 15;
    if (password.length >= 12) score += 10;
    return Math.min(100, Math.round(score));
  }, [password]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (signup && password !== confirmPassword) {
      setError("Those passwords don’t match yet.");
      return;
    }

    const form = new FormData(event.currentTarget);
    const payload = {
      name: signup ? String(form.get("name") ?? "") : undefined,
      email: String(form.get("email") ?? ""),
      password,
      remember: form.get("remember") === "on",
      returnTo,
    };

    setLoading(true);
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = (await response.json()) as AuthResponse;
      if (!response.ok || !result.ok) {
        setError(result.error || "Something went wrong. Try again.");
        return;
      }
      const destination = result.redirectTo || returnTo || "/account";
      window.location.assign(signup ? `/welcome?next=${encodeURIComponent(destination)}` : destination);
    } catch {
      setError("Dropcart couldn’t connect just now. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className={`auth-shell auth-shell-${mode}`}>
      <motion.header
        className="auth-topbar"
        initial={reduceMotion ? false : { opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={dropcartSpring}
      >
        <a href="/" className="auth-brand" aria-label="Dropcart home">
          <DropcartWordmark />
        </a>
        <a href="/" className="auth-back">
          <ArrowLeft size={15} aria-hidden="true" />
          Back to Dropcart
        </a>
      </motion.header>

      <motion.section
        className="auth-stage"
        initial={reduceMotion ? false : "hidden"}
        animate="shown"
        variants={stageSequence}
      >
        <motion.aside className="auth-visual" aria-label="Dropcart account benefits" variants={reveal}>
          <motion.img
            className="auth-visual-image"
            src="/groceries.webp"
            alt=""
            aria-hidden="true"
            initial={reduceMotion ? false : { opacity: 0.78, scale: 1.055 }}
            animate={{ opacity: 1, scale: 1.015 }}
            transition={reduceMotion ? { duration: 0 } : { duration: MOTION_TIMING.slow, ease: [0.16, 1, 0.3, 1] }}
          />
          <div className="auth-visual-wash" aria-hidden="true" />
          <div className="auth-visual-grain" aria-hidden="true" />

          <motion.div className="auth-visual-top" variants={quietReveal}>
            <div className="auth-local-pill">
              <MapPin size={14} aria-hidden="true" />
              Inverness, Florida
            </div>
            <div className="auth-visual-monogram" aria-hidden="true">D</div>
          </motion.div>

          <motion.div className="auth-floating-status" variants={quietReveal}>
            <div className="auth-floating-status-head">
              <span className="auth-status-dot" aria-hidden="true" />
              <span>Your unload flow</span>
              <strong>Simple</strong>
            </div>
            <div className="auth-route-line" aria-hidden="true">
              <span className="is-done"><ShoppingBag size={13} /></span>
              <i />
              <span><MapPin size={13} /></span>
              <i />
              <span><Check size={13} /></span>
            </div>
            <div className="auth-route-labels" aria-hidden="true">
              <span>Store</span><span>Home</span><span>Kitchen</span>
            </div>
          </motion.div>

          <motion.div className="auth-visual-copy" variants={reveal}>
            <p className="auth-visual-kicker">From checkout to put-away.</p>
            <h1 className="market-display">
              <AnimatedWords
                lines={signup ? ["Less lifting.", "More living."] : ["Welcome back.", "Let’s keep it light."]}
                accentLine={1}
                trigger="inherit"
                delay={0.02}
              />
            </h1>
            <p className="auth-visual-body">
              {signup
                ? "Create one account for saved details, live unload status, and faster rebooking when the trunk is full again."
                : "Everything you need for the next unload is waiting in one calm dashboard."}
            </p>
            <div className="auth-visual-details" aria-label="Dropcart account features">
              <span><Check size={13} aria-hidden="true" /> Saved details</span>
              <span><Check size={13} aria-hidden="true" /> Live status</span>
              <span><Check size={13} aria-hidden="true" /> Quick rebooking</span>
            </div>
          </motion.div>
        </motion.aside>

        <motion.section className="auth-panel" aria-labelledby="auth-title" variants={reveal}>
          <motion.div className="auth-panel-note" variants={quietReveal}>
            <span>{signup ? "NEW ACCOUNT" : "YOUR ACCOUNT"}</span>
            <strong>{signup ? "Set it up once. Rebook in seconds." : "Pick up right where you left off."}</strong>
          </motion.div>

          <motion.div className="auth-form-shell auth-form-card" variants={quietReveal}>
            <div className="auth-mode-switch" aria-label="Account action">
              <a className={!signup ? "is-active" : ""} href="/login">Log in</a>
              <a className={signup ? "is-active" : ""} href="/signup">Create account</a>
            </div>

            <div className="auth-secure-line">
              <span><ShieldCheck size={14} aria-hidden="true" /> Secure Dropcart account</span>
              <span className="auth-secure-chip">Private</span>
            </div>

            <div className="auth-form-heading">
              <p>{signup ? "START HERE" : "WELCOME BACK"}</p>
              <h2 id="auth-title">
                <AnimatedWords
                  lines={signup ? ["Your Dropcart", "starts here."] : ["Welcome back", "to Dropcart."]}
                  trigger="inherit"
                  delay={0.03}
                />
              </h2>
              <span>
                {signup
                  ? "A free account keeps your details, requests, and rebooking in one place."
                  : "Log in to see your current unload, history, and saved details."}
              </span>
            </div>

            <form className="auth-form" onSubmit={submit} noValidate>
              {signup && (
                <div className="auth-field">
                  <label className="auth-field-label" htmlFor="auth-name">Your name</label>
                  <div className="auth-input-wrap">
                    <span className="auth-field-icon"><UserRound size={17} aria-hidden="true" /></span>
                    <input id="auth-name" name="name" type="text" autoComplete="name" placeholder="Your name" required minLength={2} maxLength={70} />
                  </div>
                </div>
              )}

              <div className="auth-field">
                <label className="auth-field-label" htmlFor="auth-email">Email address</label>
                <div className="auth-input-wrap">
                  <span className="auth-field-icon"><Mail size={17} aria-hidden="true" /></span>
                  <input id="auth-email" name="email" type="email" autoComplete="email" inputMode="email" placeholder="you@example.com" required maxLength={254} />
                </div>
              </div>

              <div className="auth-field">
                <div className="auth-field-label-row">
                  <label className="auth-field-label" htmlFor="auth-password">Password</label>
                  <span>{signup ? "8–128 characters" : "Your Dropcart password"}</span>
                </div>
                <div className="auth-input-wrap">
                  <span className="auth-field-icon"><LockKeyhole size={17} aria-hidden="true" /></span>
                  <input
                    id="auth-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete={signup ? "new-password" : "current-password"}
                    placeholder={signup ? "Create a password" : "Enter your password"}
                    required
                    minLength={8}
                    maxLength={128}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                  />
                  <button className="auth-password-toggle" type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword((value) => !value)}>
                    {showPassword ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}
                  </button>
                </div>
                {signup && (
                  <div className="auth-password-meter" aria-label="Password strength">
                    <i style={{ width: `${passwordProgress}%` }} />
                  </div>
                )}
              </div>

              {signup && (
                <div className="auth-field">
                  <label className="auth-field-label" htmlFor="auth-confirm-password">Confirm password</label>
                  <div className="auth-input-wrap">
                    <span className="auth-field-icon"><LockKeyhole size={17} aria-hidden="true" /></span>
                    <input
                      id="auth-confirm-password"
                      name="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      placeholder="Type it again"
                      required
                      minLength={8}
                      maxLength={128}
                      value={confirmPassword}
                      onChange={(event) => setConfirmPassword(event.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="auth-form-meta">
                <label className="auth-remember">
                  <input name="remember" type="checkbox" defaultChecked />
                  <span aria-hidden="true"><Check size={12} /></span>
                  Keep me signed in
                </label>
                <span className="auth-meta-note">Protected session</span>
              </div>

              {error && <motion.div className="auth-error" role="alert" aria-live="polite" initial={reduceMotion ? false : { opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} transition={dropcartSpring}>{error}</motion.div>}

              <motion.button
                className="auth-submit"
                type="submit"
                disabled={loading}
                whileHover={reduceMotion ? undefined : { y: -1 }}
                whileTap={reduceMotion ? undefined : { scale: 0.992 }}
                transition={dropcartSpring}
              >
                <span>{loading ? (signup ? "Creating account…" : "Logging in…") : (signup ? "Create my account" : "Log in")}</span>
                <ArrowRight size={18} aria-hidden="true" />
              </motion.button>
            </form>

            <div className="auth-trust-row">
              <span><ShieldCheck size={14} aria-hidden="true" /> Passwords are hashed</span>
              <span><LockKeyhole size={14} aria-hidden="true" /> HttpOnly session</span>
            </div>

            <p className="auth-switch-copy">
              {signup ? "Already have a Dropcart account?" : "First time using Dropcart?"}{" "}
              <a href={signup ? "/login" : "/signup"}>{signup ? "Log in" : "Create an account"}</a>
            </p>
          </motion.div>
        </motion.section>
      </motion.section>

      <motion.footer className="auth-footer" initial={reduceMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: reduceMotion ? 0 : MOTION_TIMING.base, delay: reduceMotion ? 0 : 0.18 }}>
        <span>Dropcart · Inverness, FL</span>
        <span>From trunk to kitchen.</span>
      </motion.footer>
    </main>
  );
}
