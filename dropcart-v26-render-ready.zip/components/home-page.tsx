"use client";

import { ArrowUpRight, Check, HeartHandshake, House, LockKeyhole, MapPin, Quote, ShoppingBag, ShoppingBasket, Smartphone, Star } from "lucide-react";
import { motion, useReducedMotion, useScroll, useSpring, useTransform } from "motion/react";
import { AnimatedWords } from "@/components/animated-text";
import { BookingForm } from "@/components/booking-form";
import { DropcartWordmark } from "@/components/dropcart-wordmark";
import { Faq } from "@/components/faq";
import { getImageAsset } from "@/lib/image-assets";
import { MOTION_TIMING, dropcartSpring, getRevealVariants } from "@/lib/motion-system";

const steps = [
  { n: "01", icon: Smartphone, title: "Check out. Check in.", text: "Before you leave the store, tell us when you’ll be home and how much you’re bringing." },
  { n: "02", icon: House, title: "Make your way home.", text: "Once we confirm your request, we’ll arrange a time to meet you right at your door." },
  { n: "03", icon: ShoppingBasket, title: "Leave the lifting to us.", text: "We carry your groceries from your vehicle to your kitchen, or another spot you choose." },
];
const sampleReviews = [
  { quote: "The easiest part of the whole grocery run. I pulled in, opened the trunk, and the heavy part was handled.", detail: "Weekly grocery run" },
  { quote: "Exactly the kind of help I would want after a long day — simple, friendly, and straight to the kitchen.", detail: "Full-trunk unload" },
  { quote: "Booking before leaving the store makes so much sense. It feels like the last step of grocery shopping is finally solved.", detail: "Quick evening unload" },
];

const doorstepImage = getImageAsset("doorstep");
const unpackingImage = getImageAsset("unpacking");


type HomeUser = { displayName: string; email: string };
type HomePageProps = { user: HomeUser | null; signInHref: string; signUpHref: string; signOutHref: string };

function firstName(value: string) {
  const readable = value.includes("@") ? value.split("@")[0] : value;
  return readable.replace(/[._-]+/g, " ").trim().split(/\s+/)[0] || "there";
}

function initials(value: string) {
  const readable = value.includes("@") ? value.split("@")[0] : value;
  const parts = readable.replace(/[._-]+/g, " ").trim().split(/\s+/).filter(Boolean);
  return (parts.slice(0, 2).map((part) => part[0]).join("") || "D").toUpperCase();
}

export default function HomePage({ user, signInHref, signUpHref, signOutHref }: HomePageProps) {
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const heroArtY = useTransform(scrollYProgress, [0, 0.28], reduceMotion ? [0, 0] : [0, -20]);
  const heroArtRotate = useTransform(scrollYProgress, [0, 0.28], reduceMotion ? [0, 0] : [0, -0.22]);
  const heroArtScale = useTransform(scrollYProgress, [0, 0.28], reduceMotion ? [1, 1] : [1, 1.01]);
  const scrollSpring = { stiffness: 105, damping: 28, mass: 0.82, restDelta: 0.001 };
  const heroArtYSmooth = useSpring(heroArtY, scrollSpring);
  const heroArtRotateSmooth = useSpring(heroArtRotate, scrollSpring);
  const heroArtScaleSmooth = useSpring(heroArtScale, scrollSpring);

  const reveal = getRevealVariants(!!reduceMotion, 14);
  const heroParent = {
    hidden: {},
    // Keep the landing entrance deliberately subtle; this value also anchors the site-wide rhythm.
    shown: { transition: { staggerChildren: reduceMotion ? 0 : 0.07, delayChildren: reduceMotion ? 0 : MOTION_TIMING.sectionDelay } },
  };
  const heroChild = getRevealVariants(!!reduceMotion, 14);

  return (
    <>
      <a href="#book" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:rounded-xl focus:bg-white focus:p-4">Skip to booking</a>
      <motion.header
        className="topbar shell"
        initial={reduceMotion ? false : { opacity: 0, y: -14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={dropcartSpring}
      >
        <a href="/" className="brand" aria-label="Dropcart home"><DropcartWordmark /></a>
        <nav aria-label="Main navigation" className="nav-capsule">
          <a className="nav-link" href="#how-it-works">How it works</a>
          <a className="nav-link" href="#pricing">Pricing</a>
          <a className="nav-link" href="#why-dropcart">Why Dropcart</a>
          <a className="nav-link" href="#reviews">Reviews</a>
          <a className="nav-link" href="#questions">FAQs</a>
        </nav>
        <div className="topbar-actions">
          {user ? (
            <>
              <a href="/account" className="account-chip" aria-label="Open your Dropcart account">
                <span className="account-avatar" aria-hidden="true">{initials(user.displayName)}</span>
                <span className="account-chip-copy"><span>Signed in</span><strong>{firstName(user.displayName)}</strong></span>
              </a>
              <a href={signOutHref} target="_top" className="account-link">Sign out</a>
            </>
          ) : (
            <>
              <a href={signInHref} className="account-link">Log in</a>
              <a href={signUpHref} className="account-signup" aria-label="Create a Dropcart account">Create account <ArrowUpRight size={15} aria-hidden="true" /></a>
            </>
          )}
          <motion.a href="#book" className="pill-button" whileHover={reduceMotion ? undefined : { y: -1, scale: 1.004 }} whileTap={reduceMotion ? undefined : { scale: 0.988 }} transition={dropcartSpring}>
            Book an unload <ArrowUpRight size={16} aria-hidden="true" />
          </motion.a>
        </div>
      </motion.header>

      <main>
        <section className="hero" aria-label="Grocery unloading and booking">
          <motion.div className="hero-copy" variants={heroParent} initial="hidden" animate="shown">
            <motion.div variants={heroChild} className="eyebrow"><MapPin size={14} aria-hidden="true" /> A local hand in Inverness, FL</motion.div>
            <motion.h1 variants={heroChild} className="hero-title market-display"><AnimatedWords lines={["Less lifting.", "More living."]} accentLine={1} trigger="inherit" delay={0.02} /></motion.h1>
            <motion.p variants={heroChild} className="hero-description"><strong>You shop. We’ll bring it inside.</strong><br />Book a helping hand before you leave the store.<br className="hidden xl:block" /> We’ll take your groceries from trunk to kitchen.</motion.p>
            <motion.p variants={heroChild} className="hero-account-note">
              <LockKeyhole size={14} aria-hidden="true" />
              {user ? <>Signed in as <strong>{firstName(user.displayName)}</strong>. <a href="/account">View your account</a></> : <>New to Dropcart? <a href={signUpHref}>Create a free account</a> or <a href={signInHref}>log in</a>.</>}
            </motion.p>
          </motion.div>

          <BookingForm />

          <motion.div className="hero-art" style={{ y: heroArtYSmooth, rotate: heroArtRotateSmooth, scale: heroArtScaleSmooth }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <motion.img
              src="/groceries.webp"
              width={1536}
              height={1024}
              alt="Two full grocery bags with fresh fruit, vegetables, and bread"
              fetchPriority="high"
              className="grocery-visual"
              initial={reduceMotion ? false : { opacity: 0, y: 14, scale: 0.985 }}
              animate={reduceMotion ? { opacity: 1 } : { opacity: 1, y: [0, -3, 0], scale: [1, 1.003, 1] }}
              transition={reduceMotion ? { duration: 0 } : { opacity: { duration: 0.5 }, y: { duration: 8.5, repeat: Infinity, ease: "easeInOut" }, scale: { duration: 8.5, repeat: Infinity, ease: "easeInOut" } }}
            />
            <motion.div
              className="art-label"
              initial={reduceMotion ? false : { opacity: 0, x: -8, y: 6, rotate: -3.5 }}
              animate={reduceMotion ? { opacity: 1 } : { opacity: 1, x: 0, y: [0, -1.5, 0], rotate: -3 }}
              transition={reduceMotion ? { duration: 0 } : { opacity: { duration: 0.45, delay: 0.18 }, x: dropcartSpring, y: { duration: 7.5, repeat: Infinity, ease: "easeInOut", delay: 0.4 } }}
            >
              <span className="art-label-icon"><ShoppingBag size={20} strokeWidth={1.6} aria-hidden="true" /></span><div><strong>From your car. To your kitchen.</strong><small>We’ve got the heavy part.</small></div>
            </motion.div>
            <motion.span className="hero-side-note" aria-hidden="true" initial={reduceMotion ? false : { opacity: 0, x: 8 }} animate={{ opacity: 0.75, x: 0 }} transition={{ ...dropcartSpring, delay: 0.25 }}>FULL BAGS. LIGHTER DAYS.</motion.span>
          </motion.div>
        </section>

        <section className="benefits-row shell" aria-label="What comes with your unload">
          {[
            [House, "All the way inside", "Set down right where you need them."],
            [HeartHandshake, "Real people. A little extra care.", "A helping hand, close to home."],
            [Check, "Only when you need us", "No subscriptions or ongoing commitments."],
          ].map(([Icon, title, text], index) => {
            const BenefitIcon = Icon as typeof House;
            return (
              <motion.div
                className="benefit"
                key={String(title)}
                variants={reveal}
                initial="hidden"
                whileInView="shown"
                viewport={{ once: true, amount: 0.45 }}
                transition={{ ...dropcartSpring, delay: reduceMotion ? 0 : index * MOTION_TIMING.itemStagger }}
                whileHover={reduceMotion ? undefined : { y: -2 }}
              >
                <BenefitIcon size={21} strokeWidth={1.6} aria-hidden="true" /><div><strong>{String(title)}</strong><p>{String(text)}</p></div>
              </motion.div>
            );
          })}
        </section>

        <motion.section
          id="pricing"
          className="pricing-section shell"
          variants={reveal}
          initial="hidden"
          whileInView="shown"
          viewport={{ once: true, amount: 0.22 }}
          transition={dropcartSpring}
        >
          <div className="pricing-intro">
            <div><p className="section-eyebrow mb-4">Simple, upfront pricing</p><h2 className="section-title"><AnimatedWords lines={["Pick the load.", "See the price."]} trigger="inherit" delay={0.04} /></h2></div>
            <p>No membership. No hidden service fee. Your unload price is based on how many grocery bags you’re bringing.</p>
          </div>
          <div className="pricing-grid">
            {[
              { name: "A few things", bags: "1–5 bags", price: "$14.99", note: "Quick grocery runs" },
              { name: "Weekly shop", bags: "6–15 bags", price: "$19.99", note: "Most grocery trips", featured: true },
              { name: "A full trunk", bags: "16+ bags", price: "$27.99", note: "Big restocks & full carts" },
            ].map((tier, index) => (
              <motion.article
                key={tier.name}
                className={`pricing-card${tier.featured ? " featured" : ""}`}
                initial={reduceMotion ? false : { opacity: 0, y: 14, scale: 0.994 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, amount: 0.35 }}
                transition={{ ...dropcartSpring, delay: reduceMotion ? 0 : index * MOTION_TIMING.itemStagger }}
                whileHover={reduceMotion ? undefined : { y: -3, scale: 1.004 }}
              >
                {tier.featured && <span className="pricing-popular">Most common</span>}
                <span className="pricing-icon"><ShoppingBag size={21} strokeWidth={1.7} aria-hidden="true" /></span>
                <p className="pricing-name">{tier.name}</p>
                <p className="pricing-bags">{tier.bags}</p>
                <div className="pricing-price"><strong>{tier.price}</strong><span>/ unload</span></div>
                <p className="pricing-note-copy">{tier.note}</p>
                <a className="pricing-book" href="#book">Choose this load <ArrowUpRight size={15} aria-hidden="true" /></a>
              </motion.article>
            ))}
          </div>
          <motion.div className="stairs-price-note" whileHover={reduceMotion ? undefined : { y: -1 }} transition={dropcartSpring}>
            <span className="stairs-price-icon"><House size={19} strokeWidth={1.7} aria-hidden="true" /></span>
            <div><strong>Stairs at home?</strong><p>Add <b>+$5</b> to any unload. You’ll see the total before you send your request.</p></div>
          </motion.div>
        </motion.section>

        <section id="how-it-works" className="how-section shell">
          <div className="how-section-lead">
            <motion.div className="section-intro" variants={reveal} initial="hidden" whileInView="shown" viewport={{ once: true, amount: 0.35 }} transition={dropcartSpring}>
              <div><p className="section-eyebrow mb-4">A better end to your grocery run</p><h2 className="section-title"><AnimatedWords lines={["Three steps.", "Zero heavy lifting."]} trigger="inherit" delay={0.04} /></h2></div>
              <p>Keep your favorite store.<br />Leave the last few trips to us.</p>
            </motion.div>
            {doorstepImage && <motion.figure className="how-photo" initial={reduceMotion ? false : { opacity: 0, y: 14, rotate: 1.5 }} whileInView={{ opacity: 1, y: 0, rotate: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ ...dropcartSpring, delay: reduceMotion ? 0 : 0.08 }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={doorstepImage.src} alt={doorstepImage.alt} loading="lazy" decoding="async" />
              <figcaption>Right at the door.</figcaption>
            </motion.figure>}
          </div>
          <div className="steps-grid">
            {steps.map((item, index) => (
              <motion.article
                className="step-card"
                key={item.n}
                variants={reveal}
                initial="hidden"
                whileInView="shown"
                viewport={{ once: true, amount: 0.28 }}
                transition={{ ...dropcartSpring, delay: reduceMotion ? 0 : index * MOTION_TIMING.itemStagger }}
                whileHover={reduceMotion ? undefined : { y: -3, scale: 1.004 }}
                whileTap={reduceMotion ? undefined : { scale: 0.992 }}
              >
                <div className="step-top"><span className="step-icon"><item.icon size={23} strokeWidth={1.6} aria-hidden="true" /></span><span className="step-number">STEP {item.n}</span></div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </motion.article>
            ))}
          </div>
        </section>

        <motion.section
          className="care-panel shell"
          id="why-dropcart"
          variants={reveal}
          initial="hidden"
          whileInView="shown"
          viewport={{ once: true, amount: 0.28 }}
          transition={dropcartSpring}
          whileHover={reduceMotion ? undefined : { y: -2, scale: 1.002 }}
        >
          <div className="care-copy"><span className="care-icon"><HeartHandshake size={27} strokeWidth={1.5} aria-hidden="true" /></span><p className="section-eyebrow mb-3">Made for real life</p><h2 className="section-title"><AnimatedWords lines={["A little help.", "A lot of relief."]} trigger="inherit" delay={0.04} /></h2><p className="mt-5">Taking it easy, recovering from an injury, or just carrying a full day? Everyone could use an extra pair of hands.</p><p className="mt-4">You don’t need a reason to ask.</p><div className="care-signoff"><House size={19} aria-hidden="true" /><span>Your groceries. Your home. Your pace.</span></div></div>
          {unpackingImage && <figure className="care-visual"><img src={unpackingImage.src} alt={unpackingImage.alt} loading="lazy" decoding="async"/><figcaption>Less lifting. More living.</figcaption></figure>}
        </motion.section>

        <motion.section
          id="reviews"
          className="reviews-section shell"
          variants={reveal}
          initial="hidden"
          whileInView="shown"
          viewport={{ once: true, amount: 0.22 }}
          transition={dropcartSpring}
          aria-labelledby="reviews-title"
        >
          <div className="reviews-heading">
            <div><p className="section-eyebrow mb-4">The experience we’re building</p><h2 className="section-title" id="reviews-title"><AnimatedWords lines={["A lighter finish", "to grocery day."]} trigger="inherit" delay={0.04} /></h2></div>
            <div className="reviews-heading-note"><span className="reviews-stars" aria-hidden="true">{[1,2,3,4,5].map((star) => <Star key={star} size={16} fill="currentColor" />)}</span><strong>Review preview</strong><p>Replace these previews with verified customer reviews as they come in.</p></div>
          </div>
          <div className="reviews-rail">
            {sampleReviews.map((review, index) => <motion.article
              className={`review-card${index === 0 ? " review-featured" : ""}`}
              key={review.detail}
              initial={reduceMotion ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.32 }}
              transition={{ ...dropcartSpring, delay: reduceMotion ? 0 : index * MOTION_TIMING.itemStagger }}
              whileHover={reduceMotion ? undefined : { y: -3 }}
            >
              <div className="review-card-top"><span className="review-quote"><Quote size={18} aria-hidden="true" /></span><span className="review-sample-badge">Sample review</span></div>
              <div className="review-stars" aria-label="5 out of 5 stars">{[1,2,3,4,5].map((star) => <Star key={star} size={15} fill="currentColor" aria-hidden="true" />)}</div>
              <blockquote>“{review.quote}”</blockquote>
              <footer><span className="review-avatar" aria-hidden="true">D</span><div><strong>Example customer</strong><small>{review.detail}</small></div></footer>
            </motion.article>)}
          </div>
          <div className="reviews-cta"><div><HeartHandshake size={20} aria-hidden="true" /><span><strong>Used Dropcart already?</strong><small>Your account can prompt for feedback after a completed unload.</small></span></div>{user ? <a href="/account">Open your account <ArrowUpRight size={15} aria-hidden="true" /></a> : <a href={signUpHref}>Create an account <ArrowUpRight size={15} aria-hidden="true" /></a>}</div>
        </motion.section>

        <motion.section id="questions" className="faq-section shell" variants={reveal} initial="hidden" whileInView="shown" viewport={{ once: true, amount: 0.2 }} transition={dropcartSpring}>
          <div><p className="section-eyebrow mb-4">The little details</p><h2 className="section-title"><AnimatedWords lines={["Good questions.", "Simple answers."]} trigger="inherit" delay={0.04} /></h2><p className="mt-6 max-w-[260px] text-base leading-relaxed text-muted-foreground">Everything you need to know before your first unload.</p></div>
          <Faq />
        </motion.section>
      </main>

      <motion.footer className="footer shell" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: reduceMotion ? 0 : 0.55 }}>
        <a href="/" className="brand" aria-label="Dropcart home"><DropcartWordmark /></a>
        <p>A little help. A whole lot lighter.</p>
        <small>© {new Date().getUTCFullYear()} Dropcart</small>
      </motion.footer>
    </>
  );
}
