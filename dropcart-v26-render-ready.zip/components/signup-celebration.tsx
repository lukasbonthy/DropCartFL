"use client";

import { ArrowRight, Check, CheckCircle2, House, MapPin, ShoppingBag, Sparkles } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { DropcartWordmark } from "@/components/dropcart-wordmark";
import { dropcartSpring, getRevealVariants, getStaggerTransition } from "@/lib/motion-system";

type SignupCelebrationProps = {
  displayName: string;
  nextHref: string;
};

const particles = [
  { left: "8%", top: "13%", x: -13, y: 74, rotate: -34, delay: 0.04, kind: "leaf" },
  { left: "18%", top: "7%", x: 23, y: 92, rotate: 42, delay: 0.12, kind: "dot" },
  { left: "34%", top: "10%", x: -8, y: 68, rotate: 26, delay: 0.18, kind: "bar" },
  { left: "66%", top: "8%", x: 17, y: 82, rotate: -54, delay: 0.08, kind: "leaf" },
  { left: "81%", top: "7%", x: -21, y: 91, rotate: 57, delay: 0.15, kind: "dot" },
  { left: "93%", top: "16%", x: 7, y: 65, rotate: -27, delay: 0.2, kind: "bar" },
];

function firstName(value: string) {
  return value.trim().split(/\s+/)[0] || "there";
}

function initials(value: string) {
  const parts = value.trim().split(/\s+/).filter(Boolean);
  return (parts[0]?.[0] ?? "D") + (parts.length > 1 ? parts.at(-1)?.[0] ?? "" : "");
}

export function SignupCelebration({ displayName, nextHref }: SignupCelebrationProps) {
  const reduceMotion = !!useReducedMotion();
  const reveal = getRevealVariants(reduceMotion, 16);
  const quietReveal = getRevealVariants(reduceMotion, 9);
  const sequence = {
    hidden: {},
    shown: { transition: getStaggerTransition(reduceMotion, 0.065, 0.08) },
  };

  return (
    <main className="celebration-shell">
      <div className="celebration-glow celebration-glow-a" aria-hidden="true" />
      <div className="celebration-glow celebration-glow-b" aria-hidden="true" />

      {!reduceMotion && (
        <div className="celebration-confetti" aria-hidden="true">
          {particles.map((particle, index) => (
            <motion.i
              key={`${particle.left}-${index}`}
              className={`celebration-particle is-${particle.kind}`}
              style={{ left: particle.left, top: particle.top }}
              initial={{ opacity: 0, y: -18, x: 0, rotate: 0, scale: 0.72 }}
              animate={{ opacity: [0, 1, 1, 0], y: particle.y, x: particle.x, rotate: particle.rotate, scale: [0.72, 1, 0.94] }}
              transition={{ duration: 1.4, delay: particle.delay, ease: [0.16, 1, 0.3, 1] }}
            />
          ))}
        </div>
      )}

      <motion.header
        className="celebration-topbar"
        initial={reduceMotion ? false : { opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={dropcartSpring}
      >
        <a href="/" className="celebration-brand" aria-label="Dropcart home"><DropcartWordmark /></a>
        <span className="celebration-top-status"><Check size={14} aria-hidden="true" /> Account created</span>
      </motion.header>

      <motion.section className="celebration-stage" variants={sequence} initial="hidden" animate="shown" aria-labelledby="celebration-title">
        <motion.div className="celebration-story" variants={reveal}>
          <div className="celebration-story-noise" aria-hidden="true" />
          <motion.div className="celebration-success-orb" variants={quietReveal}>
            <motion.span
              initial={reduceMotion ? false : { scale: 0.62, rotate: -9 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={dropcartSpring}
            >
              <CheckCircle2 size={38} strokeWidth={1.8} aria-hidden="true" />
            </motion.span>
            <Sparkles className="celebration-spark" size={19} aria-hidden="true" />
          </motion.div>
          <motion.p className="celebration-kicker" variants={quietReveal}>WELCOME TO DROPCART</motion.p>
          <motion.h1 id="celebration-title" className="market-display celebration-title" variants={reveal}>
            You made it, <span>{firstName(displayName)}.</span>
          </motion.h1>
          <motion.p className="celebration-lede" variants={quietReveal}>
            Your next grocery run officially has an easier ending. Book before you leave the store and we’ll take the heavy part from there.
          </motion.p>

          <motion.div className="celebration-story-route" variants={quietReveal} aria-label="Dropcart unload journey">
            <span><ShoppingBag size={16} aria-hidden="true"/><small>Checkout</small></span>
            <i aria-hidden="true"><b /></i>
            <span><House size={16} aria-hidden="true"/><small>Home</small></span>
            <i aria-hidden="true"><b /></i>
            <span><Check size={16} aria-hidden="true"/><small>Put away</small></span>
          </motion.div>

          <motion.p className="celebration-story-line" variants={quietReveal}>Less lifting. More living.</motion.p>
        </motion.div>

        <motion.aside className="celebration-pass" variants={quietReveal} aria-label="Your Dropcart account is ready">
          <div className="celebration-pass-top">
            <span><i aria-hidden="true" /> Account ready</span>
            <small>DROPCART / 001</small>
          </div>

          <div className="celebration-pass-profile">
            <span className="celebration-pass-avatar" aria-hidden="true">{initials(displayName).toUpperCase()}</span>
            <div><small>Your home base</small><strong>{displayName}</strong><span>Ready for your first unload</span></div>
          </div>

          <div className="celebration-pass-divider" aria-hidden="true"><span /><span /></div>

          <div className="celebration-ready-list">
            <div><span><Check size={15} aria-hidden="true" /></span><p><strong>Account ready</strong><small>Your details stay together.</small></p></div>
            <div><span><MapPin size={15} aria-hidden="true" /></span><p><strong>Local service</strong><small>Inverness & nearby.</small></p></div>
            <div><span><ShoppingBag size={15} aria-hidden="true" /></span><p><strong>Ready to book</strong><small>No membership required.</small></p></div>
          </div>

          <motion.a
            href="/#book"
            className="celebration-primary"
            whileHover={reduceMotion ? undefined : { y: -2, scale: 1.006 }}
            whileTap={reduceMotion ? undefined : { scale: 0.986 }}
            transition={dropcartSpring}
          >
            <span><ShoppingBag size={18} aria-hidden="true" /> Book your first unload</span>
            <ArrowRight size={18} aria-hidden="true" />
          </motion.a>
          <a className="celebration-secondary" href={nextHref}>Open my dashboard <ArrowRight size={15} aria-hidden="true" /></a>
          <p className="celebration-footnote">No subscription. Just help when you want it.</p>
        </motion.aside>
      </motion.section>
    </main>
  );
}
