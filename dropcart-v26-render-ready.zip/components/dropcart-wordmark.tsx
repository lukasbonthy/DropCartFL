import { ShoppingBag } from "lucide-react";

export function DropcartWordmark() {
  return <>
    <span className="brand-mark"><ShoppingBag size={23} strokeWidth={2.1} aria-hidden="true" /></span>
    <span className="brand-word market-wordmark" aria-hidden="true">
      <span className="brand-letter brand-letter--d">d</span>
      <span className="brand-letter brand-letter--r">r</span>
      <span className="brand-letter brand-letter--o">o</span>
      <span className="brand-letter brand-letter--p">p</span>
      <span className="brand-letter brand-letter--c">c</span>
      <span className="brand-letter brand-letter--a">a</span>
      <span className="brand-letter brand-letter--r brand-letter--r-tail">r</span>
      <span className="brand-letter brand-letter--t">t</span>
      <span className="brand-dot">.</span>
    </span>
  </>;
}
