"use client";

import { motion, useReducedMotion } from "motion/react";
import { MOTION_TIMING, getStaggerTransition, getWordVariants } from "@/lib/motion-system";

type AnimatedWordsProps = {
  lines: string[];
  accentLine?: number;
  trigger?: "mount" | "view" | "inherit";
  delay?: number;
  className?: string;
};

export function AnimatedWords({
  lines,
  accentLine,
  trigger = "view",
  delay = 0,
  className = "",
}: AnimatedWordsProps) {
  const reduceMotion = !!useReducedMotion();

  const textStagger = getStaggerTransition(reduceMotion, delay, MOTION_TIMING.wordStagger);
  const container = {
    hidden: {},
    shown: {
      transition: {
        ...textStagger,
        staggerChildren: reduceMotion ? 0 : MOTION_TIMING.wordStagger,
      },
    },
  };

  const word = getWordVariants(reduceMotion);

  const motionProps = trigger === "inherit"
    ? {}
    : trigger === "mount"
      ? { initial: reduceMotion ? false : "hidden", animate: "shown" as const }
      : {
          initial: reduceMotion ? false : "hidden",
          whileInView: "shown" as const,
          viewport: { once: true, amount: 0.62 },
        };

  return (
    <motion.span
      className={`text-reveal ${className}`.trim()}
      aria-label={lines.join(" ")}
      variants={container}
      {...motionProps}
    >
      {lines.map((line, lineIndex) => (
        <span
          key={`${line}-${lineIndex}`}
          className={`text-reveal-line ${lineIndex === accentLine ? "text-reveal-accent" : ""}`.trim()}
          aria-hidden="true"
        >
          {line.split(/\s+/).map((token, wordIndex, words) => (
            <span className="text-reveal-token" key={`${token}-${wordIndex}`}>
              <motion.span className="text-reveal-word" variants={word}>{token}</motion.span>
              {wordIndex < words.length - 1 ? " " : null}
            </span>
          ))}
        </span>
      ))}
    </motion.span>
  );
}
