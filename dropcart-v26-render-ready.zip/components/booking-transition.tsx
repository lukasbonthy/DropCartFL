"use client";

import { forwardRef, useCallback, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion, useIsPresent, useReducedMotion } from "motion/react";
import { getStepMotion } from "@/lib/booking-motion";
import { MOTION_TIMING, dropcartEase } from "@/lib/motion-system";

type Direction = { direction: number; reducedMotion: boolean };
const variants = {
  enter: ({ direction, reducedMotion }: Direction) => getStepMotion(direction, reducedMotion).enter,
  center: ({ direction, reducedMotion }: Direction) => getStepMotion(direction, reducedMotion).center,
  exit: ({ direction, reducedMotion }: Direction) => getStepMotion(direction, reducedMotion).exit,
};

const StepPanel = forwardRef<HTMLDivElement, {
  children: ReactNode;
  motionData: Direction;
  onHeight: (height: number) => void;
}>(function StepPanel({ children, motionData, onHeight }, forwardedRef) {
  const localRef = useRef<HTMLDivElement | null>(null);
  const present = useIsPresent();
  const setRef = useCallback((node: HTMLDivElement | null) => {
    localRef.current = node;
    if (typeof forwardedRef === "function") forwardedRef(node);
    else if (forwardedRef) forwardedRef.current = node;
  }, [forwardedRef]);

  useLayoutEffect(() => {
    const node = localRef.current;
    if (!node || !present) return;
    const measure = () => onHeight(node.getBoundingClientRect().height);
    measure();
    // Validation messages, textarea resizing and responsive wrapping also resize the card.
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    return () => observer.disconnect();
  }, [present, onHeight]);

  return <motion.div
    ref={setRef}
    className="booking-step-panel space-y-4"
    custom={motionData}
    variants={variants}
    initial="enter"
    animate="center"
    exit="exit"
    aria-hidden={!present ? true : undefined}
    inert={!present ? true : undefined}
  >{children}</motion.div>;
});

export function BookingTransition({ step, direction, children }: { step: number; direction: number; children: ReactNode }) {
  const [height, setHeight] = useState<number | null>(null);
  const reducedMotion = !!useReducedMotion();
  const motionData = { direction, reducedMotion };
  return <motion.div
    className="booking-step-viewport"
    initial={false}
    animate={{ height: height === null ? "auto" : height + 12 }}
    transition={reducedMotion ? { duration: 0 } : { duration: MOTION_TIMING.base, ease: dropcartEase }}
  >
    <AnimatePresence mode="popLayout" initial={false} custom={motionData}>
      <StepPanel key={step} motionData={motionData} onHeight={setHeight}>{children}</StepPanel>
    </AnimatePresence>
  </motion.div>;
}
