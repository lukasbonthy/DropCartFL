import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const bookings=sqliteTable("bookings",{
 id:text("id").primaryKey(),
 reference:text("reference").notNull().unique(),
 requestDigest:text("request_digest").notNull(),
 createdAt:integer("created_at").notNull(),
 arrivalAt:integer("arrival_at").notNull(),
 etaMinutes:integer("eta_minutes").notNull(),
 status:text("status").notNull().default("pending"),
 customerName:text("customer_name").notNull(),
 phone:text("phone").notNull(),
 address:text("address").notNull(),
 city:text("city").notNull(),
 state:text("state").notNull().default("FL"),
 zip:text("zip").notNull(),
 groceryLoad:text("grocery_load").notNull(),
 stairs:integer("stairs",{mode:"boolean"}).notNull(),
 notes:text("notes").notNull(),
 contactConsent:integer("contact_consent",{mode:"boolean"}).notNull(),
 sourceKey:text("source_key").notNull(),
 userId:text("user_id"),
},table=>[
 index("idx_bookings_source_created").on(table.sourceKey,table.createdAt),
 index("idx_bookings_user_created").on(table.userId,table.createdAt),
]);


export const users=sqliteTable("users",{
 id:text("id").primaryKey(),
 email:text("email").notNull().unique(),
 displayName:text("display_name").notNull(),
 passwordHash:text("password_hash").notNull(),
 createdAt:integer("created_at").notNull(),
});

export const sessions=sqliteTable("sessions",{
 id:text("id").primaryKey(),
 userId:text("user_id").notNull(),
 tokenHash:text("token_hash").notNull().unique(),
 createdAt:integer("created_at").notNull(),
 expiresAt:integer("expires_at").notNull(),
},table=>[
 index("idx_sessions_user").on(table.userId),
 index("idx_sessions_expiry").on(table.expiresAt),
]);

export const authAttempts=sqliteTable("auth_attempts",{
 id:text("id").primaryKey(),
 keyHash:text("key_hash").notNull(),
 createdAt:integer("created_at").notNull(),
},table=>[
 index("idx_auth_attempts_key_created").on(table.keyHash,table.createdAt),
]);
