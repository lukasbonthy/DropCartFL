export type DropcartImage = {
  id: "unpacking" | "doorstep";
  src: string;
  alt: string;
  sourcePage: string;
  credit: string;
};

// Pexels free-to-use photographs selected for the two supporting lifestyle cards.
export const dropcartImages: DropcartImage[] = [
  {
    id: "unpacking",
    src: "https://images.pexels.com/photos/7677886/pexels-photo-7677886.jpeg?auto=compress&cs=tinysrgb&w=1600",
    alt: "Person unpacking fresh groceries from a paper bag in a bright kitchen",
    sourcePage: "https://www.pexels.com/photo/woman-taking-out-the-groceries-from-paper-bag-7677886/",
    credit: "PNW Production / Pexels",
  },
  {
    id: "doorstep",
    src: "https://images.pexels.com/photos/7362954/pexels-photo-7362954.jpeg?auto=compress&cs=tinysrgb&w=1600",
    alt: "Paper grocery bag resting beside a welcoming white front door",
    sourcePage: "https://www.pexels.com/photo/brown-box-and-groceries-in-bag-beside-white-wooden-door-7362954/",
    credit: "RDNE Stock project / Pexels",
  },
];

export function getImageAsset(id: DropcartImage["id"] | string) {
  return dropcartImages.find(image => image.id === id);
}
