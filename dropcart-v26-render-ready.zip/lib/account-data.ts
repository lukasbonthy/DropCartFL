export type BookingSummary = {
  reference: string;
  created_at: number;
  arrival_at: number;
  eta_minutes: number;
  status: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  grocery_load: string;
  stairs: number;
};

type AccountCounts = { total: number; active: number; completed: number };
export type AccountHistory = { bookings: BookingSummary[]; counts: AccountCounts };

export async function readAccountHistory(db: D1Database, userId: string): Promise<AccountHistory> {
  if (!userId) throw new Error("An authenticated account is required.");
  const [history, summary] = await db.batch([
    db.prepare(`SELECT reference, created_at, arrival_at, eta_minutes, status, address, city, state, zip, grocery_load, stairs
      FROM bookings WHERE user_id = ? ORDER BY created_at DESC, reference DESC LIMIT 20`).bind(userId),
    db.prepare(`SELECT COUNT(*) AS total,
      COALESCE(SUM(CASE WHEN status IN ('pending', 'confirmed') THEN 1 ELSE 0 END), 0) AS active,
      COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END), 0) AS completed
      FROM bookings WHERE user_id = ?`).bind(userId),
  ]);
  if (!history?.success || !summary?.success || !summary.results?.[0]) throw new Error("Account history is unavailable.");
  return { bookings: history.results as unknown as BookingSummary[], counts: summary.results[0] as unknown as AccountCounts };
}

const zone = "America/New_York";
export function formatAccountDate(timestamp: number) {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: zone }).format(timestamp);
}
export function formatAccountTime(timestamp: number) {
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit", timeZone: zone, timeZoneName: "short" }).format(timestamp);
}
export function accountFirstName(value: string) {
  return readableName(value).split(/\s+/)[0] || "there";
}
export function accountInitials(value: string) {
  return (readableName(value).split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join("") || "D").toUpperCase();
}
function readableName(value: string) {
  return (value.includes("@") ? value.split("@")[0] : value).replace(/[._-]+/g, " ").trim();
}
export function accountLoadLabel(value: string) {
  return ({ small: "1–5 bags", medium: "6–15 bags", large: "16+ bags" } as Record<string, string>)[value] ?? "Grocery unload";
}
export function statusPresentation(value: string) {
  switch (value) {
    case "pending": return { label: "Awaiting confirmation", tone: "pending", stage: 0, description: "Your request is saved. Our team needs to confirm availability and arrival time before your booking is final." };
    case "confirmed": return { label: "Confirmed", tone: "confirmed", stage: 1, description: "Your unload has been confirmed. Refer to the arrival details agreed with our team." };
    case "completed": return { label: "Completed", tone: "completed", stage: 2, description: "This unload is marked complete. Thanks for letting us take care of the heavy part." };
    case "cancelled": return { label: "Cancelled", tone: "cancelled", stage: -1, description: "This request has been cancelled. You can start a new request whenever you need a hand." };
    default: return { label: "Status unavailable", tone: "unknown", stage: -1, description: "We can’t display a status for this request right now. Check back for an update." };
  }
}
