import { getRevealVariants, getStaggerTransition } from "./motion-system.ts";

export function getDashboardReveal(reducedMotion: boolean) {
  return getRevealVariants(reducedMotion, 12);
}

export function getDashboardStagger(reducedMotion: boolean) {
  return getStaggerTransition(reducedMotion, 0.04, 0.07);
}
