import { createSessionToken, digestSessionToken, normalizeEmail } from './auth-core.mjs';


let authSchemaReady: Promise<void> | null = null;

export async function ensureAuthSchema(db: D1Database) {
  if (!authSchemaReady) {
    authSchemaReady = db.exec(`
      CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY NOT NULL, email TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
      CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
      CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
      CREATE TABLE IF NOT EXISTS auth_attempts (id TEXT PRIMARY KEY NOT NULL, key_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
      CREATE INDEX IF NOT EXISTS idx_auth_attempts_key_created ON auth_attempts(key_hash, created_at);
    `).then(() => undefined).catch((error) => { authSchemaReady = null; throw error; });
  }
  return authSchemaReady;
}

export type DropcartUserRecord = {
  id: string;
  email: string;
  display_name: string;
  password_hash: string;
  created_at: number;
};

export type DropcartSessionUser = {
  userId: string;
  email: string;
  displayName: string;
};

export async function findUserByEmail(db: D1Database, email: string) {
  await ensureAuthSchema(db);
  return db.prepare('SELECT id, email, display_name, password_hash, created_at FROM users WHERE email = ? LIMIT 1')
    .bind(normalizeEmail(email))
    .first<DropcartUserRecord>();
}

export async function createUser(db: D1Database, input: { email: string; displayName: string; passwordHash: string }) {
  await ensureAuthSchema(db);
  const id = crypto.randomUUID();
  const createdAt = Date.now();
  const result = await db.prepare('INSERT OR IGNORE INTO users (id, email, display_name, password_hash, created_at) VALUES (?, ?, ?, ?, ?)')
    .bind(id, normalizeEmail(input.email), input.displayName.trim(), input.passwordHash, createdAt)
    .run();
  if (!result.success || Number(result.meta?.changes ?? 0) !== 1) return null;
  return { id, email: normalizeEmail(input.email), displayName: input.displayName.trim(), createdAt };
}

export async function createSession(db: D1Database, userId: string, ttlMs: number) {
  await ensureAuthSchema(db);
  const token = createSessionToken();
  const tokenHash = await digestSessionToken(token);
  const now = Date.now();
  const expiresAt = now + ttlMs;
  await db.prepare('DELETE FROM sessions WHERE expires_at <= ?').bind(now).run();
  const result = await db.prepare('INSERT INTO sessions (id, user_id, token_hash, created_at, expires_at) VALUES (?, ?, ?, ?, ?)')
    .bind(crypto.randomUUID(), userId, tokenHash, now, expiresAt)
    .run();
  if (!result.success) throw new Error('Could not create session.');
  return { token, expiresAt };
}

export async function userFromSessionToken(db: D1Database, token: string | undefined | null): Promise<DropcartSessionUser | null> {
  await ensureAuthSchema(db);
  if (!token) return null;
  const tokenHash = await digestSessionToken(token);
  const now = Date.now();
  const row = await db.prepare(`SELECT users.id AS user_id, users.email AS email, users.display_name AS display_name
    FROM sessions JOIN users ON users.id = sessions.user_id
    WHERE sessions.token_hash = ? AND sessions.expires_at > ? LIMIT 1`)
    .bind(tokenHash, now)
    .first<{ user_id: string; email: string; display_name: string }>();
  if (!row) return null;
  return { userId: row.user_id, email: row.email, displayName: row.display_name };
}

export async function deleteSession(db: D1Database, token: string | undefined | null) {
  await ensureAuthSchema(db);
  if (!token) return;
  const tokenHash = await digestSessionToken(token);
  await db.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(tokenHash).run();
}

export async function authRateLimited(db: D1Database, keyHash: string, limit = 8, windowMs = 10 * 60_000) {
  await ensureAuthSchema(db);
  const cutoff = Date.now() - windowMs;
  const row = await db.prepare('SELECT COUNT(*) AS count FROM auth_attempts WHERE key_hash = ? AND created_at > ?')
    .bind(keyHash, cutoff)
    .first<{ count: number }>();
  return Number(row?.count ?? 0) >= limit;
}

export async function recordFailedAuth(db: D1Database, keyHash: string) {
  await ensureAuthSchema(db);
  const now = Date.now();
  await db.prepare('DELETE FROM auth_attempts WHERE created_at <= ?').bind(now - 24 * 60 * 60_000).run();
  await db.prepare('INSERT INTO auth_attempts (id, key_hash, created_at) VALUES (?, ?, ?)')
    .bind(crypto.randomUUID(), keyHash, now)
    .run();
}

export async function clearAuthFailures(db: D1Database, keyHash: string) {
  await ensureAuthSchema(db);
  await db.prepare('DELETE FROM auth_attempts WHERE key_hash = ?').bind(keyHash).run();
}
