import { bookingSchema } from "./booking-data";
import { BookingError, digest, saveBooking } from "./booking-store";

export async function handleBooking(request:Request,getDb:()=>D1Database,userId:string|null=null):Promise<Response>{
 const reply=(data:object,status:number)=>Response.json(data,{status,headers:{"Cache-Control":"no-store"}});
 if(request.method!=="POST")return reply({error:"Method not allowed."},405);
 if(!request.headers.get("content-type")?.toLowerCase().startsWith("application/json"))return reply({error:"Please submit the booking form."},415);
 const origin=request.headers.get("origin");
 if(origin&&origin!==new URL(request.url).origin)return reply({error:"Please submit your request from Dropcart."},403);
 let payload:unknown;
 try {
  if(Number(request.headers.get("content-length"))>8192)return reply({error:"Your request is too large."},413);
  const body=await request.text();
  if(new TextEncoder().encode(body).byteLength>8192)return reply({error:"Your request is too large."},413);
  payload=JSON.parse(body);
 } catch {return reply({error:"We couldn’t read your request. Please try again."},400);}
 const result=bookingSchema.safeParse(payload);
 if(!result.success)return reply({error:result.error.issues[0]?.message||"Please check your details."},400);
 try {
  const sourceKey=await digest((request.headers.get("cf-connecting-ip")||"local")+"|"+new Date().toISOString().slice(0,10));
  const receipt=await saveBooking(getDb(),result.data,sourceKey,Date.now(),userId);
  return reply(receipt,201);
 } catch(error){
  if(error instanceof BookingError)return reply({error:error.message},error.status);
  // Log no customer data or request payloads.
  console.error("Dropcart booking storage unavailable");
  return reply({error:"We couldn’t save your request just now. Your details are still here—please try again shortly."},503);
 }
}
