export const MOTION_TIMING = {
  wordStagger: 0.042,
  itemStagger: 0.07,
  sectionDelay: 0.04,
  quick: 0.22,
  base: 0.42,
  slow: 0.62,
} as const;

export const dropcartEase = [0.16, 1, 0.3, 1] as const;

export const dropcartSpring = {
  type: "spring" as const,
  stiffness: 190,
  damping: 25,
  mass: 0.74,
};

export const dropcartQuickSpring = {
  type: "spring" as const,
  stiffness: 245,
  damping: 30,
  mass: 0.7,
};

export function getRevealVariants(reducedMotion: boolean, distance = 14) {
  return {
    hidden: { opacity: reducedMotion ? 1 : 0, y: reducedMotion ? 0 : distance },
    shown: {
      opacity: 1,
      y: 0,
      transition: reducedMotion
        ? { duration: 0 }
        : { duration: MOTION_TIMING.base, ease: dropcartEase },
    },
  };
}

export function getStaggerTransition(
  reducedMotion: boolean,
  delayChildren = MOTION_TIMING.sectionDelay,
  staggerChildren = MOTION_TIMING.itemStagger,
) {
  return reducedMotion
    ? { duration: 0 }
    : { delayChildren, staggerChildren };
}

export function getWordVariants(reducedMotion: boolean) {
  return {
    hidden: {
      opacity: reducedMotion ? 1 : 0,
      y: reducedMotion ? 0 : "0.62em",
      rotateX: reducedMotion ? 0 : -7,
    },
    shown: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: reducedMotion ? { duration: 0 } : dropcartSpring,
    },
  };
}
