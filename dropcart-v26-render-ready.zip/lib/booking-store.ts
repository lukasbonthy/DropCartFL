import type { BookingData } from "./booking-data";

type StoredReceipt={reference:string;arrival_at:number;request_digest:string;status:string};
export class BookingError extends Error {
 status:number;
 constructor(message:string,status:number){super(message);this.status=status;}
}
export async function digest(value:string){
 const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value));
 return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("");
}
export async function saveBooking(db:D1Database, data:BookingData, sourceKey:string, now=Date.now(), userId:string|null=null){
 const fingerprint=await digest(JSON.stringify(data));
 const read=()=>db.prepare("SELECT reference, arrival_at, request_digest, status FROM bookings WHERE id = ?").bind(data.requestId).first<StoredReceipt>();
 const receipt=(row:StoredReceipt)=>{
  if(row.request_digest!==fingerprint)throw new BookingError("A request with this reference was already received with different details. Reload the page to start a new request.",409);
  return {reference:row.reference,status:row.status,arrivalAt:row.arrival_at};
 };
 const existing=await read();
 if(existing)return receipt(existing);
 const reference="DC-"+crypto.randomUUID().replaceAll("-","").slice(0,10).toUpperCase();
 const result=await db.prepare(`INSERT INTO bookings (id, reference, request_digest, created_at, arrival_at, eta_minutes, status, customer_name, phone, address, city, state, zip, grocery_load, stairs, notes, contact_consent, source_key, user_id)
 SELECT ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, 'FL', ?, ?, ?, ?, 1, ?, ?
 WHERE (SELECT COUNT(*) FROM bookings WHERE source_key = ? AND created_at > ?) < 5
 ON CONFLICT(id) DO NOTHING`).bind(data.requestId,reference,fingerprint,now,now+data.eta*60000,data.eta,data.name,data.phone,data.address,data.city,data.zip,data.load,data.stairs?1:0,data.notes,sourceKey,userId,sourceKey,now-600000).run();
 if(!result.success)throw new Error("Unable to save booking.");
 const row=await read();
 if(!row)throw new BookingError("You’ve sent several requests recently. Please wait a few minutes before trying again.",429);
 return receipt(row);
}
