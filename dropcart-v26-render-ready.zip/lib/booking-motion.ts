import { MOTION_TIMING, dropcartEase } from "./motion-system.ts";

/** Keep the form sharp: translate/fade the content, never scale the card. */
export function getStepMotion(direction: number, reducedMotion: boolean) {
  const sign = direction < 0 ? -1 : 1;
  const instant = { duration: 0, delay: 0 };
  return {
    enter: { opacity: reducedMotion ? 1 : 0, x: reducedMotion ? 0 : sign * 12, transition: instant },
    center: { opacity: 1, x: 0, transition: reducedMotion ? instant : { duration: MOTION_TIMING.quick, delay: MOTION_TIMING.itemStagger, ease: dropcartEase } },
    exit: { opacity: 0, x: reducedMotion ? 0 : sign * -10, transition: reducedMotion ? instant : { duration: 0.14, delay: 0, ease: dropcartEase } },
  };
}
