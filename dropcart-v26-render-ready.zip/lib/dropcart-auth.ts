import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { getRawDb } from '@/db';
import { digestSessionToken, safeReturnPath } from './auth-core.mjs';
import { deleteSession, userFromSessionToken } from './auth-store';

export const SESSION_COOKIE = 'dropcart_session';
const REMEMBER_TTL_SECONDS = 60 * 60 * 24 * 14;
const SESSION_TTL_SECONDS = 60 * 60 * 12;

export type DropcartUser = { userId: string; email: string; displayName: string };

export async function getDropcartUser(): Promise<DropcartUser | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    return await userFromSessionToken(getRawDb(), token);
  } catch {
    return null;
  }
}

export async function requireDropcartUser(returnTo = '/account') {
  const user = await getDropcartUser();
  if (user) return user;
  redirect(`/login?return_to=${encodeURIComponent(safeReturnPath(returnTo))}`);
}

export function buildSessionCookie(token: string, options: { secure: boolean; remember: boolean }) {
  const persistence = options.remember ? `; Max-Age=${REMEMBER_TTL_SECONDS}` : '';
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${persistence}${options.secure ? '; Secure' : ''}`;
}

export function clearSessionCookie(secure: boolean) {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;
}

export function sessionTtlMs(remember: boolean) {
  return (remember ? REMEMBER_TTL_SECONDS : SESSION_TTL_SECONDS) * 1000;
}

export async function destroyCurrentSession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  try { await deleteSession(getRawDb(), token); } catch { /* clear client cookie anyway */ }
}

export async function requestFingerprint(prefix: string, email = '') {
  const requestHeaders = await headers();
  const ip = requestHeaders.get('cf-connecting-ip') || requestHeaders.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  return digestSessionToken(`${prefix}|${ip}|${email.trim().toLowerCase()}`);
}
