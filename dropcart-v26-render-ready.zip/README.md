# Dropcart

A premium, responsive grocery unloading website built with React, Tailwind CSS 4, Vinext, and Cloudflare D1.

## Product behavior

The three-step form collects arrival estimate, home address, grocery load, stairs, name, phone, and notes. The final step requests contact consent and shows an editable review. A successful submission creates a durable `pending` booking and returns a reference. Availability, price, and arrival must be confirmed manually; this version sends no SMS or email, takes no payments, and dispatches no workers.

D1 stores requests in the `bookings` table, accessible to the owner through Sites data tools. No public endpoint lists customers or their addresses. New requests use prepared SQL, bounded input, same-origin checks, duplicate protection, and a limit of five requests per source per ten minutes. Do not make customer records publicly readable when adding an operator interface.

Dropcart now has first-party email/password accounts backed by D1. `/signup` creates a user with a salted PBKDF2-HMAC-SHA256 password hash, `/login` verifies credentials, and authenticated sessions use random server-side tokens stored as hashes with an HttpOnly SameSite cookie in the browser. The protected `/account` page shows that user's saved requests, and signed-in bookings are associated with the Dropcart user ID.

Service copy assumes Inverness, Florida from the business brief. Coverage is confirmed manually rather than inferred from a ZIP code. The hero image is original and generated for Dropcart; supporting lifestyle images are credited in `lib/image-assets.ts` and are sourced from Pexels free-use photo pages. There are no invented reviews, prices, live ETAs, or staff availability claims.

## Verification

- `node --experimental-strip-types --test lib/*.test.mjs`
- `node scripts/check-bookings.mjs` — exercises real generated SQL migrations with SQLite, including duplicate prevention and failure responses.
- `node scripts/check-account.mjs` — validates account isolation, complete-history counts, error handling, and Florida timestamps against real SQLite migrations.
- `node scripts/check-ui.mjs` — renders the actual account and booking components across initial, populated, empty, and unavailable states.
- `node node_modules/typescript/bin/tsc --noEmit`
- Build through the Sites build helper, or use the package build script for standalone development.

The optional WebMCP `stage_unload_request` tool fills the same visible form without submitting it or setting consent. Browsers without WebMCP use the form normally. No permitted supported browser context was available for WebMCP validation; browser visual and end-to-end QA were not run.

## Booking motion and account layout

Booking steps share a measured-height viewport. A short directional slide and fade moves the fields without scaling the text; outgoing panels are inert and hidden from assistive technology. ResizeObserver updates the viewport when validation messages, text wrapping, or the notes field changes height. Reduced-motion preferences remove movement and transition delays. The address icon has dedicated input padding.

The account workspace keeps the latest request, status progression, profile, and readable request history together. Totals cover all of the signed-in user’s records; history shows the most recent 20. Arrival estimates are labeled as originally requested and displayed in America/New_York. No live tracking, worker dispatch, payment, or notification service has been added.

### Dashboard and large-screen refinement

The account workspace gives the current request practical actions (including copy-address feedback), filterable All/Active/Completed history, larger desktop summary stats, and responsive history controls. The v18 dashboard adds a compact account pulse strip, richer stat cards, a visual trunk-to-kitchen route, more expressive quick actions, a live service-status rail card, and subtle ambient motion. All values come from the existing account history or static service copy; there is still no live worker tracking or dispatch backend.

Large desktop layouts use a wider responsive shell and hero at 1500px+ viewports so the site uses more of the available screen. Reading copy keeps explicit maximum widths while cards, imagery, pricing, reviews, and dashboard surfaces gain room. Mobile keeps the compact shell, horizontal stat strip, and existing bottom dashboard dock.

The cursor uses a lightweight 24px Dropcart arrow asset only for fine-pointer desktop surfaces. Links/buttons keep the familiar pointer hand, text fields keep the I-beam, and touch/coarse-pointer devices keep their normal system behavior. There is no JavaScript cursor-follow animation or DOM overlay.

Motion reference: https://motion.dev/docs/react-animate-presence

## Framework development reference

## Prerequisites

- Node.js `>=22.13.0`
- Portable: Windows, macOS, or Linux; no Bash required
- Managed Linux: managed Linux runtime with Bash, `flock`, `curl`, `sha256sum`, and GNU `timeout`
- Git is required only for publishing

## Sites Lifecycle

The Sites initializer copies the shared starter and selects managed-linux only when `SITES_MANAGED_LINUX_CONTAINER=1`; otherwise it selects portable. It saves the selection only in ignored `.sites-runtime/execution-profile.json`. Both profiles copy/configure first, then use the plugin's separate `install-dependencies.mjs` step to measure installation independently. Edit source under `app/` and follow the Sites skill for installation, preview, builds, and publishing.

Whenever reopening or moving a checkout, run `node <plugin-root>/scripts/configure-execution-profile.mjs` before project commands. Profile changes do not alter tracked source or require reinstalling otherwise-valid dependencies; restart an existing preview to use the new selection. Do not commit or upload `.sites-runtime/`.

This starter does not use `wrangler.jsonc`.

`install:ci` runs `npm ci` once against the shared lockfile, disables parent-workspace discovery, and includes required dev/optional dependencies despite production/omit settings. Sharp defaults to prebuilt binaries unless explicitly configured otherwise. Do not overlap installers.

- **Portable:** Preserve host HOME, npm cache, registry, proxy, temporary paths, retry/concurrency settings, and lifecycle-script policy. Use `--prefer-offline --no-audit --no-fund`.
- **Managed Linux:** Use the existing project-local HOME/cache/tmp setup and Linux install lock, tarball preflight, and timeout. Restore the image-seeded npm cache only when its lockfile hash matches; retain network fallback. Builds keep their existing timeout. These helpers are not invoked by the portable profile.

`scripts/sites-env.mjs` preserves the caller's HOME, npm cache, proxy, XDG, and temporary-directory configuration while defaulting Wrangler and Miniflare state to the checkout. If npm reports an unwritable cache, select a writable path with `npm_config_cache` for that install. The `dev` and `start` scripts also keep Wrangler logs inside the checkout. Generated `.sites-runtime/` and `.wrangler/` directories are disposable and ignored by Git.

On portable, `npm run dev` uses `vinext dev` with HMR, starting at port 5173. Vinext records the running server in ignored `.vinext/` state, rejects an ordinary duplicate launch, and recovers stale state after a stopped process; exactly simultaneous starts can race. Pass `--port <port>` or `--hostname <host>` after `npm run dev --` when needed; keep portable previews on loopback.

On managed Linux, use `sites-preview start` only for requested browser QA. The project's dev script runs Vite and accepts the supervisor's `--host 0.0.0.0 --port 4173 --strictPort` arguments. The internal browser uses `http://terminal.local:4173/`; it is not a user-facing URL. The supervisor owns the preview lifecycle. The ignored local profile survives the supervisor's cleared process environment.

The Worker uses `vinext/server/fetch-handler`, including Vinext's config-aware image handling. After building, `npm start` runs that Worker locally through Wrangler on `127.0.0.1`, sharing `.wrangler/state` with dev preview and local D1 migrations; it does not deploy the site or simulate sign-in. Use the URL printed by the server. Pass `npm start -- --port <port>` to select a different built-preview port.

Local previews use Miniflare's placeholder `Request.cf` metadata without a network lookup. Set `CLOUDFLARE_CF_FETCH_ENABLED=true` to opt into fetching preview metadata; this setting does not change hosted request metadata.

Local tool usage metrics are disabled by default. Set `WRANGLER_SEND_METRICS=true` to opt in.

## Included Shape

- edit site code under `app/`
- `lib/dropcart-auth.ts` and `lib/auth-store.ts` provide Dropcart session and account helpers
- `.openai/hosting.json` declares optional Sites D1 and R2 bindings
- `vite.config.ts` simulates declared bindings for local development
- `db/index.ts` reads the D1 binding from the Cloudflare Worker environment
- `db/schema.ts` starts intentionally empty
- `@cloudflare/workers-types` provides Worker types; `cloudflare-env.d.ts` declares optional `DB`/`BUCKET` bindings—update these declarations if binding names change
- `examples/d1/` contains an optional D1 example surface
- `drizzle.config.ts` supports local migration generation when needed

## Dropcart account authentication

Dropcart does not expose a ChatGPT sign-in option. The app uses its own email/password account flow:

- `/signup` creates the D1 user and immediately creates a Dropcart session.
- `/login` uses a generic invalid-credentials message and throttles repeated failures.
- Passwords are salted and hashed with PBKDF2-HMAC-SHA256 before storage. Plaintext passwords are never stored.
- Browser sessions use the `dropcart_session` cookie with `HttpOnly` and `SameSite=Lax`; `Secure` is added automatically on HTTPS.
- Session tokens are random and only a SHA-256 digest of the token is stored in D1.
- Auth tables self-initialize in local development. `drizzle/0002_dropcart_accounts.sql` is included for managed/production migrations.

Email verification and password-reset delivery are not implemented in this version, so add those before treating the account system as a complete production identity service.

## Local D1 migrations

For a D1-backed local preview, generate SQL with `npm run db:generate`. Build once through the Sites skill's build entrypoint (or `npm run build` for standalone use) to generate `dist/server/wrangler.json`, rebuilding if bindings change. From the project root, apply each pending migration in order:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_example.sql
```

Replace the filename with the pending migration and `DB` with your D1 binding name if different. Use `.wrangler/state`, not `.wrangler/state/v3`; Wrangler adds the versioned directories. Do not replay migrations already applied locally. This updates only the preview database; publishing applies production migrations separately.

## Diagnostic Commands

- `npm run install:ci`: perform the one locked dependency install
- `npm run dev`: start the Vite/Vinext development server
- `npm run build`: build the deployable Sites artifact
- `npm run start`: preview the built Worker locally with D1/R2 support
- `npm run db:generate`: generate Drizzle migrations after schema changes

When using the Sites plugin, follow its skill instructions for installation, builds, and publishing. These npm commands remain available for standalone use.

The portable build runs Vinext directly without a host `timeout` command. The managed-linux build uses `scripts/build-verified.sh` and its existing `SITES_BUILD_TIMEOUT` setting.

## Learn More

- [vinext Documentation](https://github.com/cloudflare/vinext)
- [Drizzle D1 Guide](https://orm.drizzle.team/docs/get-started/d1-new)

## v23 — Font motion
- Added reusable accessible word-reveal animation for major display headings.
- Homepage hero and section titles now stagger softly on load/scroll.
- Dashboard greeting/current-unload/history headings now animate in with the same system.
- Login and signup headline typography now uses the same branded motion language.
- Motion is disabled/flattened when `prefers-reduced-motion: reduce` is enabled.

## v24 auth + motion polish
- Reworked login/signup into a premium inset account card with a calmer two-panel composition.
- Unified landing, auth, booking, dashboard, and word-reveal timings through one shared motion system.
- Section headings can inherit their parent reveal so text and surfaces enter as one sequence.
- Reduced-motion behavior remains supported.
