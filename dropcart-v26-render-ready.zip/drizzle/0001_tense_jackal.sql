ALTER TABLE `bookings` ADD `user_id` text;--> statement-breakpoint
CREATE INDEX `idx_bookings_user_created` ON `bookings` (`user_id`,`created_at`);