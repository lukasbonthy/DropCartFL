import { getDropcartUser } from "@/lib/dropcart-auth";
import HomePage from "@/components/home-page";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await getDropcartUser();

  return (
    <HomePage
      user={user ? { displayName: user.displayName, email: user.email } : null}
      signInHref="/login"
      signUpHref="/signup"
      signOutHref="/api/auth/logout?return_to=/"
    />
  );
}
