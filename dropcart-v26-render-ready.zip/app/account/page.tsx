import { getRawDb } from "@/db";
import { requireDropcartUser } from "@/lib/dropcart-auth";
import { AccountDashboard } from "@/components/account-dashboard";
import { readAccountHistory, type AccountHistory } from "@/lib/account-data";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await requireDropcartUser("/account");
  let history: AccountHistory | null = null;
  try {
    history = await readAccountHistory(getRawDb(), user.userId);
  } catch {
    console.error("Dropcart account history could not be loaded.");
  }
  return <AccountDashboard user={{ displayName: user.displayName, email: user.email }} history={history} signOutHref="/api/auth/logout?return_to=/" />;
}
