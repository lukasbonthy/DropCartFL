import { getRawDb } from "@/db";
import { handleBooking } from "@/lib/booking-handler";
import { getDropcartUser } from "@/lib/dropcart-auth";

export async function POST(request: Request) {
  const user = await getDropcartUser();
  return handleBooking(request, getRawDb, user?.userId ?? null);
}
