import { getRawDb } from '@/db';
import { normalizeEmail, verifyPassword, isEmail, safeReturnPath } from '@/lib/auth-core.mjs';
import { authRateLimited, clearAuthFailures, createSession, findUserByEmail, recordFailedAuth } from '@/lib/auth-store';
import { buildSessionCookie, requestFingerprint, sessionTtlMs } from '@/lib/dropcart-auth';

const json = (body: object, status: number, headers?: HeadersInit) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store', ...headers } });

export async function POST(request: Request) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) return json({ error: 'Please submit the login form.' }, 415);
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) return json({ error: 'Please log in from Dropcart.' }, 403);
  let body: { email?: string; password?: string; remember?: boolean; returnTo?: string };
  try { body = await request.json(); } catch { return json({ error: 'We couldn’t read that login. Try again.' }, 400); }
  const email = normalizeEmail(body.email);
  const password = String(body.password ?? '');
  if (!isEmail(email) || !password) return json({ error: 'Enter your email and password.' }, 400);

  const db = getRawDb();
  const rateKey = await requestFingerprint('login', email);
  if (await authRateLimited(db, rateKey)) return json({ error: 'Too many login attempts. Try again in a few minutes.' }, 429);

  const user = await findUserByEmail(db, email);
  const valid = user ? await verifyPassword(password, user.password_hash) : false;
  if (!user || !valid) {
    await recordFailedAuth(db, rateKey);
    return json({ error: 'Email or password is incorrect.' }, 401);
  }

  await clearAuthFailures(db, rateKey);
  const remember = Boolean(body.remember);
  const session = await createSession(db, user.id, sessionTtlMs(remember));
  const secure = new URL(request.url).protocol === 'https:';
  return json({ ok: true, redirectTo: safeReturnPath(body.returnTo, '/account') }, 200, { 'Set-Cookie': buildSessionCookie(session.token, { secure, remember }) });
}
