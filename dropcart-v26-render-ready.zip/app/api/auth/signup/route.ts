import { getRawDb } from '@/db';
import { hashPassword, isEmail, normalizeEmail, safeReturnPath, validatePassword } from '@/lib/auth-core.mjs';
import { createSession, createUser, findUserByEmail } from '@/lib/auth-store';
import { buildSessionCookie, sessionTtlMs } from '@/lib/dropcart-auth';

const json = (body: object, status: number, headers?: HeadersInit) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store', ...headers } });

export async function POST(request: Request) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) return json({ error: 'Please submit the signup form.' }, 415);
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) return json({ error: 'Please create your account from Dropcart.' }, 403);
  let body: { name?: string; email?: string; password?: string; remember?: boolean; returnTo?: string };
  try { body = await request.json(); } catch { return json({ error: 'We couldn’t read that signup. Try again.' }, 400); }

  const name = String(body.name ?? '').trim().replace(/\s+/g, ' ');
  const email = normalizeEmail(body.email);
  const password = String(body.password ?? '');
  if (name.length < 2 || name.length > 70) return json({ error: 'Enter the name you want on your Dropcart account.' }, 400);
  if (!isEmail(email)) return json({ error: 'Enter a valid email address.' }, 400);
  const passwordError = validatePassword(password);
  if (passwordError) return json({ error: passwordError }, 400);

  const db = getRawDb();
  if (await findUserByEmail(db, email)) return json({ error: 'We couldn’t create that account. Try logging in if you’ve used this email before.' }, 409);

  const passwordHash = await hashPassword(password);
  const user = await createUser(db, { email, displayName: name, passwordHash });
  if (!user) return json({ error: 'We couldn’t create that account. Try logging in if you’ve used this email before.' }, 409);

  const remember = Boolean(body.remember);
  const session = await createSession(db, user.id, sessionTtlMs(remember));
  const secure = new URL(request.url).protocol === 'https:';
  return json({ ok: true, redirectTo: safeReturnPath(body.returnTo, '/account') }, 201, { 'Set-Cookie': buildSessionCookie(session.token, { secure, remember }) });
}
