import { destroyCurrentSession, clearSessionCookie } from '@/lib/dropcart-auth';
import { safeReturnPath } from '@/lib/auth-core.mjs';

export async function POST(request: Request) {
  await destroyCurrentSession();
  const secure = new URL(request.url).protocol === 'https:';
  return Response.json({ ok: true, redirectTo: '/' }, { status: 200, headers: { 'Cache-Control': 'no-store', 'Set-Cookie': clearSessionCookie(secure) } });
}

export async function GET(request: Request) {
  await destroyCurrentSession();
  const url = new URL(request.url);
  const target = safeReturnPath(url.searchParams.get('return_to') ?? '/', '/');
  return new Response(null, { status: 303, headers: { Location: target, 'Set-Cookie': clearSessionCookie(url.protocol === 'https:') } });
}
