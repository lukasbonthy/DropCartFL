import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthPage } from "@/components/auth-page";
import { getDropcartUser } from "@/lib/dropcart-auth";
import { safeReturnPath } from "@/lib/auth-core.mjs";

export const metadata: Metadata = {
  title: "Log in — Dropcart",
  description: "Log in to your Dropcart account to view unload requests, history, and book again.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ return_to?: string }> }) {
  const user = await getDropcartUser();
  if (user) redirect("/account");
  const params = await searchParams;
  return <AuthPage mode="login" returnTo={safeReturnPath(params.return_to, "/account")} />;
}
