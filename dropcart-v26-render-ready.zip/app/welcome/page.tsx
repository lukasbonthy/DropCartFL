import type { Metadata } from "next";
import { SignupCelebration } from "@/components/signup-celebration";
import { safeReturnPath } from "@/lib/auth-core.mjs";
import { requireDropcartUser } from "@/lib/dropcart-auth";

export const metadata: Metadata = {
  title: "Welcome to Dropcart",
  description: "Your Dropcart account is ready. Book your first unload or head to your dashboard.",
};

export default async function WelcomePage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const user = await requireDropcartUser("/welcome");
  const params = await searchParams;
  const nextHref = safeReturnPath(params.next, "/account");
  return <SignupCelebration displayName={user.displayName} nextHref={nextHref} />;
}
