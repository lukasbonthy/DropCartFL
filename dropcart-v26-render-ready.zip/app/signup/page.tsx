import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthPage } from "@/components/auth-page";
import { getDropcartUser } from "@/lib/dropcart-auth";
import { safeReturnPath } from "@/lib/auth-core.mjs";

export const metadata: Metadata = {
  title: "Create account — Dropcart",
  description: "Create a Dropcart account for faster booking, unload history, and easy rebooking.",
};

export default async function SignupPage({ searchParams }: { searchParams: Promise<{ return_to?: string }> }) {
  const user = await getDropcartUser();
  if (user) redirect("/account");
  const params = await searchParams;
  return <AuthPage mode="signup" returnTo={safeReturnPath(params.return_to, "/account")} />;
}
