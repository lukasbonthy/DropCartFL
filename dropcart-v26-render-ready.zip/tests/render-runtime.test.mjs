import test from "node:test";
import assert from "node:assert/strict";
import { renderPort, wranglerArgs } from "../scripts/render-runtime.mjs";

test("uses Render PORT", () => assert.equal(renderPort({PORT:"12345"}), "12345"));
test("defaults to 10000", () => assert.equal(renderPort({}), "10000"));
test("binds publicly", () => { const args=wranglerArgs("12345"); assert.ok(args.includes("0.0.0.0")); assert.ok(args.includes("12345")); });
